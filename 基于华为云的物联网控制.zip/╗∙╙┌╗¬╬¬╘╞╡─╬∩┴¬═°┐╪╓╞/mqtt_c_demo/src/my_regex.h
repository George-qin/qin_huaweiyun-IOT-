#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <regex.h>

typedef struct issue_date{
	char name[20];
	int cmd;

}issue;

char *name_d(char buf[])
{
     int ret;
     char *name=(char*)malloc(50);
    char *pattern = "w+([^\"]+)";
    regex_t preg;
    size_t nmatch = 1;
    regmatch_t pmatch[1];

    ret = regcomp(&preg, pattern, REG_EXTENDED);  //缂栬瘧姝ｅ垯琛ㄨ揪寮?

    ret = regexec(&preg, buf, nmatch, pmatch, REG_NOTEOL);  //鍖归厤瀛楃涓?

    if(ret != REG_NOERROR){  //鍖归厤澶辫触锛屾墦鍗板け璐ュ師鍥?
        int err_length = regerror(ret, &preg, NULL, 0);//鍏堣幏鍙栧け璐ュ師鍥犵殑闀垮害锛岀劧鍚庡啀寮€杈熷唴瀛樼┖闂村瓨鏀?銆?
        char *errbuf = malloc(err_length);
        regerror(ret, &preg, errbuf, err_length);
        //printf("%s\r\n", errbuf);
        free(errbuf);
        return  "meide";
    }

   // 鍖归厤鎴愬姛锛屾墦鍗板尮閰嶅埌鐨勫唴瀹?
	int m=0;
    for (int i = pmatch[0].rm_so; i < pmatch[0].rm_eo; i++)
    {
	name[m]=buf[i];
	m++;
    }
name[m]='\0';
    regfree(&preg);  //娓呯┖缂栬瘧濂界殑姝ｅ垯琛ㄨ揪寮?
	return name;
}
/*
char* name_h(char buf[])
{
     int ret;
     char *name=(char*)malloc(50);
     //char *pattern = "\"name\":\"([^\"]+)\"";
    char *pattern = "h+([^\"]+)";
    regex_t preg;
    size_t nmatch = 1;
    regmatch_t pmatch[1];

    ret = regcomp(&preg, pattern, REG_EXTENDED);  //缂栬瘧姝ｅ垯琛ㄨ揪寮?

    ret = regexec(&preg, buf, nmatch, pmatch, REG_NOTEOL);  //鍖归厤瀛楃涓?

    if(ret != REG_NOERROR){  //鍖归厤澶辫触锛屾墦鍗板け璐ュ師鍥?
        int err_length = regerror(ret, &preg, NULL, 0);//鍏堣幏鍙栧け璐ュ師鍥犵殑闀垮害锛岀劧鍚庡啀寮€杈熷唴瀛樼┖闂村瓨鏀?銆?
        char *errbuf = malloc(err_length);
        regerror(ret, &preg, errbuf, err_length);
        //printf("%s\r\n", errbuf);
        free(errbuf);
        return  "meide"; 
    }

   // 鍖归厤鎴愬姛锛屾墦鍗板尮閰嶅埌鐨勫唴瀹?
        int m=0;
    for (int i = pmatch[0].rm_so; i < pmatch[0].rm_eo; i++)
    {
        name[m]=buf[i];
        m++;
    }
    regfree(&preg);  //娓呯┖缂栬瘧濂界殑姝ｅ垯琛ㄨ揪寮?
   return name;
}

*/

int  get_cmd(char buf[])
{
	int ret;
     char name[5];
    char *pattern = "[01]\"";
    regex_t preg;
    size_t nmatch = 1;
    regmatch_t pmatch[1];

    ret = regcomp(&preg, pattern, REG_EXTENDED);  

    ret = regexec(&preg, buf, nmatch, pmatch, REG_NOTEOL);  

    if(ret != REG_NOERROR){  
        int err_length = regerror(ret, &preg, NULL, 0);
        char *errbuf = malloc(err_length);
        free(errbuf);
    }

  
	int m=0;
    for (int i = pmatch[0].rm_so; i < pmatch[0].rm_eo; i++)
    {
	name[m]=buf[i];
	m++;
    }
	name[m]='\0';
        regfree(&preg);  
	return (int)name[0]-48;
}




issue  get_data(char buf[])
{
	issue data;
	char *drv_name=(char*)malloc(50);
	char name1[100];
	strcpy(name1,name_d(buf));
	if(strcmp(name1,"meide")!=0)
	{
		strcpy(data.name,name1);
	}
	data.cmd=get_cmd(buf);
	return data;
}

